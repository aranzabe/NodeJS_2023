Primer ejemplo de servicio web con agrupación de rutas y uso de middlewares. Paquetes npm: express y dotenv.
